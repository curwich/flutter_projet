import 'package:flutter/material.dart';
import 'package:google_ml_kit/google_ml_kit.dart';
import 'package:image_picker/image_picker.dart';
import 'package:camera/camera.dart';
import 'package:oscar/transcription.dart';
import 'TranscriptionVew.dart';
late List<CameraDescription> _cameras;

void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  _cameras = await availableCameras();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: Text("RECENTS",style: TextStyle(
              color: Color.fromARGB(232, 243, 121, 131),
              fontWeight: FontWeight.bold,
              fontFamily: "PirataOne-Regular"),
          ),
          backgroundColor: Colors.white,
        ),
        body: HomePage(),
      ),
    );
  }
}


class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final ImagePicker _picker = ImagePicker();
  final textDetector =TextRecognizer();
  Future<void> _getImageFromGallery() async {
    try {
      XFile? imageFile = await _picker.pickImage(source: ImageSource.gallery);
      if (imageFile != null) {
        final inputImage = InputImage.fromFilePath(imageFile.path);
        
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => TranscriptionView(picture: imageFile)),
        );
      }
    } catch (e) {
      print('ERREUR, Veuillez réessayer : $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: Container(
          child: TranscriptionList(),
        ), 
        floatingActionButton: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: <Widget>[
            FloatingActionButton(
              heroTag: "Camera",
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => CameraScreen()),
                );
              },
              tooltip: 'Capture',
              child: Icon(Icons.camera),
            ),
            SizedBox(width: 15),
            FloatingActionButton(
              heroTag: "photoLibraryButton",
              onPressed: _getImageFromGallery,
              tooltip: 'Choisir une photo',
              child: Icon(Icons.photo_library),
            ),
          ],
        ),
      ),
    );
  }
}



class CameraScreen extends StatefulWidget {
  @override
  _CameraScreenState createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> {
  final TextRecognizer textRecognitionProcessor = GoogleMlKit.vision.textRecognizer();
  late CameraController controller;

  @override
  void initState() {
    super.initState();
    controller = CameraController(_cameras[0], ResolutionPreset.max);
    controller.initialize().then((_) {
      if (!mounted) {
        return;
      }
      setState(() {});
    }).catchError((Object e) {
      if (e is CameraException) {
        switch (e.code) {
          case 'Camera Non Accessible':
            break;
          default:
            break;
        }
      }
    });
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  Future<void> takePicture() async {
    try {
      final image = await controller.takePicture();
      Navigator.push(context, MaterialPageRoute(builder: (context)=>TranscriptionView(picture: image)));
    } on CameraException catch (e) {
      print('Erreur, Veuillez reessayer : ${e.description}');
     
    } catch (e) {
      print('REPRENDRE : $e');
      
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!controller!.value.isInitialized) {
      return Container();
    }
    return AspectRatio(
      aspectRatio: controller.value.aspectRatio,
      child: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          CameraPreview(controller),
          Positioned(
            bottom: 10,
            right: 10,
            child: FloatingActionButton(
              child: Icon(Icons.camera),
              onPressed: takePicture,
            ),
          ),
        ],
      ),
    );
  }
}

