import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'transcription.dart';
import 'main.dart';
import 'dart:io';

class TranscriptionView extends StatefulWidget {
  TranscriptionView({required this.picture, Key? key}) : super(key: key);
  XFile picture;
  @override
  State<TranscriptionView> createState() => _TranscriptionViewState();
}

class _TranscriptionViewState extends State<TranscriptionView> {
  late String _text='';
  @override
  void initState(){
    super.initState();
    WidgetsBinding.instance!.addPostFrameCallback((_) => load());
  }
  void load() async{
    File imageFile = File(widget.picture.path);
    TranscriptionList.transcriptions.add(new Transcription(imageFile.path, 'recognizedText.text'));
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          children: [
            Container(
                child: Image.network(widget.picture.path)
            ),
            Container(
              child: Text(_text),
            )
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: (){
          Navigator.push(context, MaterialPageRoute(builder: (builder)=>MyApp()));
        },
        child: Icon(Icons.home),
      ),
    );
  }
}