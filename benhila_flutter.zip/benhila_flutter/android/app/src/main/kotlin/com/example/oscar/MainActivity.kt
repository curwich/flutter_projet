package com.example.oscar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
